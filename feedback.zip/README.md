<h3>Simple Support/Feedback Button Form v1.0</h3>

To install simply change the email address in contact.php and copy and paste the code from index.html between <!-- start feedback button --> and <!-- end feedback button --> tags on to your website.

If your contact.php file is in a different directory to your webpages make sure you update line 21 to include the full url like:
var feedbackform_url = 'http://mywebsite.com/contact.php';

Example:
<a href="http://JamesBachini.com/misc/feedbackexample.html">http://JamesBachini.com/misc/feedbackexample.html</a>

There are no dependancies so it should work anywhere.

Original post:
<a href="http://jamesbachini.com/feedback-button/">Simple Floating Feedback / Support Button Form</a>

Tested on Firefox, Chrome and Edge.